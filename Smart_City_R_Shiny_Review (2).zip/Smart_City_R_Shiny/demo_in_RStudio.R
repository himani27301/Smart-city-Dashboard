# COLLEGE REVIEW DEMO — run source("demo_in_RStudio.R") in RStudio.
# Uses only base R: no package installation is needed for this demonstration.
source('R/analytics.R')
air <- load_air_data('data/air_quality.csv')
selected_city <- 'Hyderabad'
selected_year <- '2018'
city_data <- select_records(air, selected_city, selected_year)
result <- city_summary(air, selected_city, selected_year)

cat('\nSMART CITY DATA ANALYTICS — R DEMO\n')
cat('R runtime:', R.version.string, '\n')
cat('Total observations:', nrow(air), '| Cities:', length(unique(air$city)), '\n')
cat('Selection:', selected_city, selected_year, '\n')
print(head(city_data), row.names=FALSE)
cat('\nSelected records:', nrow(city_data), '\n')
cat('Mean PM2.5:', round(result$meanPM25,1), 'micrograms/m3\n')
cat('Mean source AQI:', round(result$meanAQI), '\n')

# Show data frames in RStudio Environment: air, city_data, monthly_table, categories.
monthly_table <- data.frame(Month=unlist(result$p$labels),
                            Mean_PM25=unlist(result$p$values),
                            Mean_PM10=unlist(result$pm$values))
categories <- do.call(rbind,lapply(result$buckets,function(b)
  data.frame(Category=b$name,Days=b$count,Percentage=round(b$percent,1))))
print(monthly_table,row.names=FALSE)
print(categories,row.names=FALSE)

# Two plots appear in RStudio's Plots pane and are saved as a PDF for review.
draw_demo <- function() {
  par(mfrow=c(1,2),mar=c(5,4,3,1))
  plot(as.Date(paste0(monthly_table$Month,'-01')),monthly_table$Mean_PM25,
       type='o',pch=16,col='#e64b35',lwd=2,xlab='Month',ylab='Mean PM2.5 (micrograms/m3)',
       main=paste(selected_city, selected_year))
  grid()
  barplot(categories$Days,names.arg=categories$Category,col=c('#6ac88c','#37a5ff','#f4cd29'),
          ylab='Recorded days',main='Air-quality categories',las=2)
}
draw_demo()
dir.create('outputs',showWarnings=FALSE)
pdf('outputs/RStudio_demo_plots.pdf',width=11,height=5)
draw_demo()
dev.off()
write.csv(monthly_table,'outputs/monthly_pollution.csv',row.names=FALSE)
write.csv(categories,'outputs/air_quality_categories.csv',row.names=FALSE)
writeLines(export_city_csv(air,selected_city,selected_year),'outputs/selected_city_data.csv')
stopifnot(nrow(city_data)==365L,round(result$meanPM25,1)==43.1,
          round(result$meanAQI)==98,sum(categories$Days)==365L)
cat('\nPASS: expected Hyderabad 2018 results reproduced in R.\n')
cat('Saved plots and CSV files in outputs/.\n')
cat('To run the full dashboard: source("setup.R"); shiny::runApp()\n')
