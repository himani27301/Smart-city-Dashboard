packages <- c('shiny','jsonlite')
missing <- packages[!vapply(packages,requireNamespace,logical(1),quietly=TRUE)]
if(length(missing)) install.packages(missing,repos='https://cloud.r-project.org')
message('Ready. Open app.R and click Run App, or run shiny::runApp().')
