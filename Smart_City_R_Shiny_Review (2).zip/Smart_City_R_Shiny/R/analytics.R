# Shared R analysis engine: used by RStudio/Shiny and webR hosting.
load_air_data <- function(path) {
  d <- read.csv(path, stringsAsFactors = FALSE, check.names = FALSE,
                na.strings = c('', 'NA'), fileEncoding = 'UTF-8')
  stopifnot(all(c('city','date','pm25','pm10','aqi','bucket') %in% names(d)))
  d$date <- as.character(as.Date(d$date))
  for (n in c('pm25','pm10','aqi')) d[[n]] <- suppressWarnings(as.numeric(d[[n]]))
  d$bucket[is.na(d$bucket) | d$bucket == ''] <- 'Unknown'
  d[order(d$city, d$date), , drop = FALSE]
}
finite_mean <- function(x) { x <- x[is.finite(x)]; if (length(x)) mean(x) else NA_real_ }
select_records <- function(data, city, year = 'all') {
  if (length(city) != 1L || !city %in% unique(data$city)) stop('Unknown city')
  if (length(year) != 1L || !year %in% c('all','2017','2018','2019')) stop('Invalid year')
  d <- data[data$city == city, , drop = FALSE]
  if (year != 'all') d <- d[substr(d$date,1,4) == year, , drop = FALSE]
  d
}
monthly_means <- function(d, variable) {
  months <- unique(substr(d$date, 1, 7))
  list(labels = as.list(months), values = as.list(unname(vapply(months, function(m)
    finite_mean(d[[variable]][substr(d$date, 1, 7) == m]), numeric(1)))))
}
row_lists <- function(d) lapply(seq_len(nrow(d)), function(i) as.list(d[i,,drop=FALSE]))
city_summary <- function(data, city, year = 'all') {
  d <- select_records(data, city, year)
  buckets <- unique(d$bucket)
  counts <- vapply(buckets, function(b) sum(d$bucket == b), integer(1))
  list(city = city, year = year, count = nrow(d), meanPM25 = finite_mean(d$pm25),
       meanAQI = finite_mean(d$aqi), p = monthly_means(d,'pm25'), pm = monthly_means(d,'pm10'),
       start = if(nrow(d)) d$date[1] else NA_character_,
       end = if(nrow(d)) tail(d$date,1) else NA_character_,
       buckets = lapply(seq_along(buckets), function(i) list(name=buckets[i], count=counts[i],
         percent=if(nrow(d)) 100*counts[i]/nrow(d) else 0)))
}
export_city_csv <- function(data, city, year = 'all') {
  d <- select_records(data, city, year)
  names(d) <- c('City','Date','PM2.5','PM10','AQI','AQI_Bucket')
  con <- textConnection('out','w',local=TRUE)
  write.csv(d, con, row.names=FALSE, na='')
  close(con)
  paste(out,collapse='\n')
}
read_custom_csv <- function(text) {
  if(nchar(text,type='bytes') > 5*1024*1024) stop('Please choose a CSV under 5 MB.')
  d <- read.csv(text=text, stringsAsFactors=FALSE, check.names=FALSE,
                colClasses='character', na.strings='', comment.char='')
  if(nrow(d)<1L || ncol(d)<1L) stop('CSV needs a header and at least one data row.')
  d
}
visualizer_data <- function(d) {
  numeric_cols <- which(vapply(d, function(v) any(is.finite(suppressWarnings(as.numeric(v)))),logical(1))) - 1L
  list(headers=as.list(names(d)), count=nrow(d), columns=ncol(d), numeric=as.list(unname(numeric_cols)),
       rows=lapply(seq_len(min(nrow(d),100L)),function(i) unname(as.list(d[i,,drop=FALSE]))))
}
visualizer_chart <- function(d, x, y) {
  x <- as.integer(x)+1L; y <- as.integer(y)+1L
  if(anyNA(c(x,y)) || any(c(x,y)<1L) || any(c(x,y)>ncol(d))) stop('Invalid column')
  d <- head(d,300L)
  list(title=names(d)[y], labels=as.list(d[[x]]),
       values=as.list(suppressWarnings(as.numeric(d[[y]]))))
}
new_analysis_state <- function() { e <- new.env(parent=emptyenv()); e$custom <- NULL; e }
analysis_request <- function(data, state, method, args=list()) {
  switch(method,
    bootstrap=list(version=R.version.string, records=nrow(data),
                   counts=as.list(table(data$city))),
    summary=city_summary(data,args$city,args$year),
    export=export_city_csv(data,args$city,args$year),
    sample={
      d <- select_records(data,args$city,'all')[,c('date','pm25','pm10','aqi')]
      names(d) <- c('Date','PM2.5','PM10','AQI')
      state$custom <- as.data.frame(lapply(d,as.character),check.names=FALSE)
      visualizer_data(state$custom)
    },
    import={state$custom <- read_custom_csv(args$text); visualizer_data(state$custom)},
    chart={if(is.null(state$custom)) stop('Load a dataset first'); visualizer_chart(state$custom,args$x,args$y)},
    stop('Unknown analysis request'))
}
analysis_json <- function(data,state,method,args_json='{}') {
  args <- jsonlite::fromJSON(args_json,simplifyVector=FALSE)
  jsonlite::toJSON(analysis_request(data,state,method,args),auto_unbox=TRUE,na='null',null='null',digits=15)
}
