// Native Shiny transport. No webR, no browser R fallback: analysis requires the R server.
let nextRequest=0;
const jobs=new Map();
const nativeReady=new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>reject(Error('R server connection timed out. Reload this page.')),30000);
  Shiny.addCustomMessageHandler('analysis_result',message=>{
    const job=jobs.get(message.id);if(!job)return;
    clearTimeout(job.timer);jobs.delete(message.id);
    if(message.error)job.reject(Error(message.error));else job.resolve(JSON.parse(message.json));
  });
  window.jQuery(document).one('shiny:connected',()=>{clearTimeout(timer);resolve();});
});
window.REngine={mode:'R Shiny',init:()=>nativeReady,async call(method,args={}){
  await nativeReady;
  return new Promise((resolve,reject)=>{
    const id=++nextRequest;
    const timer=setTimeout(()=>{jobs.delete(id);reject(Error('R analysis timed out. Reload to reconnect.'));},30000);
    jobs.set(id,{resolve,reject,timer});
    Shiny.setInputValue('analysis_request',{id,method,args:JSON.stringify(args)},{priority:'event'});
  });
}};
