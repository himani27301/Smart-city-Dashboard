# Open Smart_City_India.Rproj in RStudio, then click Run App.
if (!requireNamespace('shiny',quietly=TRUE) || !requireNamespace('jsonlite',quietly=TRUE)) {
  stop('Run source("setup.R") once to install shiny and jsonlite.')
}
source('R/analytics.R')
air_data <- load_air_data('data/air_quality.csv')
# Serve the identical HTML/CSS layout; Shiny supplies the native R session.
shiny::addResourcePath('assets',normalizePath('dist/assets'))
html <- paste(readLines('dist/index.html',warn=FALSE),collapse='\n')
html <- sub('<html lang="en">','<html lang="en" data-r-engine="shiny">',html,fixed=TRUE)
html <- sub('</head>','{{ headContent() }}</head>',html,fixed=TRUE)
ui <- shiny::htmlTemplate(text_=html)
server <- function(input,output,session) {
  state <- new_analysis_state()
  shiny::observeEvent(input$analysis_request, {
    req <- input$analysis_request
    tryCatch({
      answer <- analysis_json(air_data,state,req$method,req$args)
      session$sendCustomMessage('analysis_result',list(id=req$id,json=as.character(answer)))
    },error=function(e) session$sendCustomMessage('analysis_result',list(id=req$id,error=conditionMessage(e))))
  },ignoreInit=TRUE)
}
# Static files are served from www; package script creates this directory.
shiny::shinyApp(ui=ui,server=server)
