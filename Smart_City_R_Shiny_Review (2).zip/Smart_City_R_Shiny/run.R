source('setup.R')
shiny::runApp('.',host='0.0.0.0',port=as.integer(Sys.getenv('PORT','3838')),launch.browser=interactive())
